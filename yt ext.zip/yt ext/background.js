// Background script (optional)
console.log("Background script loaded.");

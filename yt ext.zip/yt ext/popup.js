document.getElementById("downloadBtn").addEventListener("click", () => {
    // Get the current active tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const currentTab = tabs[0];
        const videoUrl = currentTab.url;

        // Extract YouTube video ID
        const videoId = extractVideoId(videoUrl);



        if (videoId) {
            // Fetch MP4 download link from your server
            fetchMP4Link(videoUrl);
        } else {
            document.getElementById("status").innerText = "Invalid YouTube video URL.";
        }
    });
});

// Function to extract YouTube video ID from URL
function extractVideoId(url) {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return match && match[2].length === 11 ? match[2] : null;
}

// Function to fetch MP4 download link using your server
function fetchMP4Link(videoUrl) {
    const serverUrl = "http://localhost:3500/mp4"; // Replace with your server URL
    const apiUrl = `${serverUrl}?url=${encodeURIComponent(videoUrl)}`;

    fetch(apiUrl)
        .then((response) => {
            if (!response.ok) {
                throw new Error("Network response was not ok.");
            }
            return response.blob(); // Get the MP4 file as a blob
        })
        .then((blob) => {
            // Create a download link for the MP4 file
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = "video.mp4"; // Default filename
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            document.getElementById("status").innerText = "Downloading MP4...";
        })
        .catch((error) => {
            console.error("Error fetching MP4 link:", error);
            document.getElementById("status").innerText = "Error fetching MP4 link. Please try again.";
        });
}
